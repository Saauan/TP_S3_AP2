#!/usr/bin/python3
# -*- coding: utf-8 -*-

"""
:mod: parentheses_checker1 module

:author: Tristan Coignion, Tayebi Ajwad, Becquembois Logan

:date: 16/10/2018
:last revision: 16/10/2018

A module which verifies whether 
or not another module does well parentheses
"""

from os import sys
from stack import Stack, StackEmptyError
    
def main(filename):
    """
    return wether a file has good parentheses or not

    :param filename: (str) the name of the file we want to check
    :return: (bool)
    :UC: `filename` is a valid file
    """
    with open(filename, "r",) as instream:
        lines = instream.readlines()
        stack = Stack()

    for line in lines:
        for c in line:
            try:
                if c in {"(", "{", "["}:
                    stack.push(c)

                if c == ")":
                    if stack.pop() != "(":
                        return False

                if c == "}":
                    if stack.pop() != "{":
                        return False

                if c == "]":
                    if stack.pop() != "[":
                        return False
            except StackEmptyError:
                return False
            
    return stack.is_empty()

if len(sys.argv) == 2:
    print(main(sys.argv[1]))
else:
    print("You have to enter only one argument")
    # Display Help


